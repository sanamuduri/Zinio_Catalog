package com.sbx.api.model;

/**
 * Class stores the details of the catalog
 * 
 * @author Sarita
 *
 */
public class Catalog {
	private int id;// Catalog Id
	private String name;// Name of the catlog
	private String description;// Description of the catalog
	private String remote_identifier;// Remote identifire of the catalog
	private int status;// Status of catlog
	private String legacy_identifier;// Legacy Identifier of catalog
	private String created_at;// Catalog Creation Date
	private String modified_at;// Catalog Modification date

	/**
	 * Get the id
	 * 
	 * @return catalog id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Set the catalog id
	 * 
	 * @param id - Catalog Id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Get the name
	 * 
	 * @return name - name of the catalog
	 */
	public String getName() {
		return name;
	}

	/**
	 * Set name of catalog
	 * 
	 * @param name - Name of the catalog
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Get Catalog description
	 * 
	 * @return Description of catalog
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Set description of catalog
	 * 
	 * @param description - Description of catalog
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Get the remote identifier
	 * 
	 * @return Remote Identifier
	 */
	public String getRemote_identifier() {
		return remote_identifier;
	}

	/**
	 * Set the remote identifer
	 * 
	 * @param remote_identifier - Remote identifier
	 */
	public void setRemote_identifier(String remote_identifier) {
		this.remote_identifier = remote_identifier;
	}

	/**
	 * Get the status
	 * 
	 * @return Catalog status
	 */
	public int getStatus() {
		return status;
	}

	/**
	 * Set the status
	 * 
	 * @param status - Set Catalog status
	 */
	public void setStatus(int status) {
		this.status = status;
	}

	/**
	 * Set Catalog legacy identifier
	 * 
	 * @return Catalog legacy identifier
	 */
	public String getLegacy_identifier() {
		return legacy_identifier;
	}

	/**
	 * Set Catalog legacy identifier
	 * 
	 * @param legacy_identifier - Catalog legacy identifier
	 */
	public void setLegacy_identifier(String legacy_identifier) {
		this.legacy_identifier = legacy_identifier;
	}

	/**
	 * Get Catalog Created date
	 * 
	 * @return Catalog Created date
	 */
	public String getCreated_at() {
		return created_at;
	}

	/**
	 * Set Catalog Created date
	 * 
	 * @param created_at - Catalog Created date
	 */
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}

	/**
	 * Get Catalog Modified date
	 * 
	 * @return Catalog Modified date
	 */
	public String getModified_at() {
		return modified_at;
	}

	/**
	 * Set the modified date
	 * 
	 * @param modified_at - Catalog Modified date
	 */
	public void setModified_at(String modified_at) {
		this.modified_at = modified_at;
	}

}
