package com.sbx.api.model;

import java.util.List;

/**
 * Class hold result of catalog
 * 
 * @author Sarita
 *
 */
public class Result {
	private boolean status;// Status as true/false
	private List<Catalog> data;// Data returned by API

	/**
	 * Get the status
	 * 
	 * @return Status value
	 */
	public boolean isStatus() {
		return status;
	}

	/**
	 * Set status
	 * 
	 * @param status - Status value
	 */
	public void setStatus(boolean status) {
		this.status = status;
	}

	/**
	 * Get list of catalog
	 * 
	 * @return List of catalog
	 */
	public List<Catalog> getData() {
		return data;
	}

	/**
	 * Set List of catalog
	 * 
	 * @param data - List of catalog
	 */
	public void setData(List<Catalog> data) {
		this.data = data;
	}

}
