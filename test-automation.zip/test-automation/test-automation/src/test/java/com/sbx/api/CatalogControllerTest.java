package com.sbx.api;

import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.json.JSONObject;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbx.api.model.Catalog;
import com.sbx.api.model.Result;

import io.restassured.RestAssured;
import io.restassured.response.Response;

/**
 * Catalog controller test
 * 
 * @author Sarita
 *
 */
public class CatalogControllerTest {
	// Get catalog rest api
	private static final String GET_CATALOGS_API = "https://sbx-api-sec.ziniopro.com/catalog/v2/catalogs?access_token=";

	/**
	 * Test get catalogs api without access token
	 */
	@Test
	public void testWithokenoutAccessToken() {
		Response response = given().when().get(GET_CATALOGS_API);
		JSONObject jsonObject = new JSONObject(response.getBody().asString());
		String message = jsonObject.getString("message");
		assertNotNull(message);
		assertTrue(!message.trim().isEmpty());
	}

	/**
	 * Test access token api
	 */
	@Test
	public void testGetAccessToken() {
		String client_id = "C9EeT8cWZ7u7LcYYvOTlFyONeHCN3OZp";
		String client_secret = "ns1huoaQM3aCPq1yh6dcizirP99cMrsc";
		String grant_type = "client_credentials";
		String access_token_api = "https://sbx-api-sec.ziniopro.com/oauth/v2/tokens";
		Response response = given().auth().preemptive()
				.basic(client_id, client_secret)
				.contentType("application/x-www-form-urlencoded")
				.formParam("grant_type", grant_type).when()
				.post(access_token_api);

		JSONObject jsonObject = new JSONObject(response.getBody().asString());
		String accessToken = jsonObject.get("access_token").toString();
		String tokenType = jsonObject.get("token_type").toString();
		assertNotNull(accessToken);
		assertTrue(!accessToken.trim().isEmpty());
		assertNotNull(tokenType);
		assertTrue(!tokenType.trim().isEmpty());
		assertEquals("bearer", tokenType);
	}

	/**
	 * Test get token for invalid client id
	 */
	@Test
	public void testInvalidClientId() {
		String client_id = "C9EeT8cWZ7u7LcYYvOTlFyONeHCN3OZ";
		String client_secret = "ns1huoaQM3aCPq1yh6dcizirP99cMrsc";
		String grant_type = "client_credentials";
		String access_token_api = "https://sbx-api-sec.ziniopro.com/oauth/v2/tokens";
		Response response = given().auth().preemptive()
				.basic(client_id, client_secret)
				.contentType("application/x-www-form-urlencoded")
				.formParam("grant_type", grant_type).when()
				.post(access_token_api);

		JSONObject jsonObject = new JSONObject(response.getBody().asString());
		String error = jsonObject.get("error").toString();
		String error_description = jsonObject.get("error_description")
				.toString();
		assertNotNull(error);
		assertTrue(!error.trim().isEmpty());
		assertNotNull(error_description);
		assertTrue(!error_description.trim().isEmpty());
	}

	/**
	 * Test get catalogs api
	 */
	@Test
	public void testGetCatalogs() {

		String client_id = "C9EeT8cWZ7u7LcYYvOTlFyONeHCN3OZp";
		String client_secret = "ns1huoaQM3aCPq1yh6dcizirP99cMrsc";
		String grant_type = "client_credentials";
		String access_token_api = "https://sbx-api-sec.ziniopro.com/oauth/v2/tokens";
		Response response = given().auth().preemptive()
				.basic(client_id, client_secret)
				.contentType("application/x-www-form-urlencoded")
				.formParam("grant_type", grant_type).when()
				.post(access_token_api);
		JSONObject jsonObject = new JSONObject(response.getBody().asString());
		String accessToken = jsonObject.get("access_token").toString();
		RestAssured.baseURI = GET_CATALOGS_API + accessToken;
		response = given().when().get(RestAssured.baseURI);
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			Result actual = objectMapper
					.readValue(response.getBody().asString(), Result.class);
			// Check result data
			assertNotNull(actual);
			Result expectedResult = getExpectedResult();
			assertEquals(expectedResult.isStatus(), actual.isStatus());
			assertNotNull(expectedResult.getData());
			assertTrue(!expectedResult.getData().isEmpty());
			assertTrue(expectedResult.getData().size() == expectedResult
					.getData().size());
			// Check for each catalog we got from api is same as expected.
			for (int i = 0; i < expectedResult.getData().size(); i++) {
				Catalog expectedCatalog = expectedResult.getData().get(i);
				Catalog actualCatalog = expectedResult.getData().get(i);
				assertTrue(expectedCatalog.getId() == actualCatalog.getId());
				assertEquals(expectedCatalog.getCreated_at(),
						actualCatalog.getCreated_at());

				assertEquals("Modified date is not same as expected",
						expectedCatalog.getModified_at(),
						actualCatalog.getModified_at());
				assertEquals("Catalog name is not same as expected",
						expectedCatalog.getName(), actualCatalog.getName());
				assertEquals("Remote Identifier is not same as expected",
						expectedCatalog.getRemote_identifier(),
						actualCatalog.getRemote_identifier());
				assertEquals("Status is not same as expected",
						expectedCatalog.getStatus(), actualCatalog.getStatus());
				assertEquals("Description is not same as expected",
						expectedCatalog.getDescription(),
						actualCatalog.getDescription());
				assertEquals("Legacy Identifier is not same as expected",
						expectedCatalog.getLegacy_identifier(),
						actualCatalog.getLegacy_identifier());
			}
		} catch (JsonProcessingException e) {
			fail(e.getMessage());
		}

	}

	/**
	 * Get the expected result of catalogs api
	 * 
	 * @return {@linkResult} instance
	 */
	private Result getExpectedResult() {
		String jsonStr = "{\n" + "    \"status\": true,\n" + "    \"data\": [\n"
				+ "        {\n" + "            \"id\": 1542,\n"
				+ "            \"name\": \"Zinio Demo Catalog\",\n"
				+ "            \"description\": \"Zinio Demo Catalog Description\",\n"
				+ "            \"remote_identifier\": \"098XYZ123\",\n"
				+ "            \"status\": 1,\n"
				+ "            \"legacy_identifier\": \"1234567\",\n"
				+ "            \"created_at\": \"2019-08-08T15:30:44+0000\",\n"
				+ "            \"modified_at\": \"2019-08-08T15:30:44+0000\"\n"
				+ "        },\n" + "        {\n" + "            \"id\": 1540,\n"
				+ "            \"name\": \"Our State North Carolina1\",\n"
				+ "            \"description\": null,\n"
				+ "            \"remote_identifier\": null,\n"
				+ "            \"status\": 1,\n"
				+ "            \"legacy_identifier\": null,\n"
				+ "            \"created_at\": \"2019-07-11T08:22:14+0000\",\n"
				+ "            \"modified_at\": \"2019-07-11T08:22:14+0000\"\n"
				+ "        },\n" + "        {\n" + "            \"id\": 1538,\n"
				+ "            \"name\": \"Hawaii Fishing News\",\n"
				+ "            \"description\": null,\n"
				+ "            \"remote_identifier\": null,\n"
				+ "            \"status\": 1,\n"
				+ "            \"legacy_identifier\": null,\n"
				+ "            \"created_at\": \"2019-06-25T14:07:53+0000\",\n"
				+ "            \"modified_at\": \"2019-06-25T14:07:53+0000\"\n"
				+ "        },\n" + "        {\n" + "            \"id\": 1537,\n"
				+ "            \"name\": \"Pets Magazine\",\n"
				+ "            \"description\": null,\n"
				+ "            \"remote_identifier\": null,\n"
				+ "            \"status\": 1,\n"
				+ "            \"legacy_identifier\": null,\n"
				+ "            \"created_at\": \"2019-06-17T15:18:12+0000\",\n"
				+ "            \"modified_at\": \"2019-06-17T15:18:12+0000\"\n"
				+ "        },\n" + "        {\n" + "            \"id\": 1536,\n"
				+ "            \"name\": \"Australian & New Zealand Handgun\",\n"
				+ "            \"description\": null,\n"
				+ "            \"remote_identifier\": null,\n"
				+ "            \"status\": 1,\n"
				+ "            \"legacy_identifier\": null,\n"
				+ "            \"created_at\": \"2019-06-17T15:16:05+0000\",\n"
				+ "            \"modified_at\": \"2019-06-17T15:16:05+0000\"\n"
				+ "        },\n" + "        {\n" + "            \"id\": 1535,\n"
				+ "            \"name\": \"Save Our Seas\",\n"
				+ "            \"description\": null,\n"
				+ "            \"remote_identifier\": null,\n"
				+ "            \"status\": 1,\n"
				+ "            \"legacy_identifier\": null,\n"
				+ "            \"created_at\": \"2019-06-17T15:14:54+0000\",\n"
				+ "            \"modified_at\": \"2019-06-17T15:14:54+0000\"\n"
				+ "        },\n" + "        {\n" + "            \"id\": 1534,\n"
				+ "            \"name\": \"CKGSB Knowledge\",\n"
				+ "            \"description\": null,\n"
				+ "            \"remote_identifier\": null,\n"
				+ "            \"status\": 1,\n"
				+ "            \"legacy_identifier\": null,\n"
				+ "            \"created_at\": \"2019-06-17T15:12:02+0000\",\n"
				+ "            \"modified_at\": \"2019-06-17T15:12:02+0000\"\n"
				+ "        },\n" + "        {\n" + "            \"id\": 1533,\n"
				+ "            \"name\": \"YMag\",\n"
				+ "            \"description\": null,\n"
				+ "            \"remote_identifier\": null,\n"
				+ "            \"status\": 1,\n"
				+ "            \"legacy_identifier\": null,\n"
				+ "            \"created_at\": \"2019-06-17T15:10:30+0000\",\n"
				+ "            \"modified_at\": \"2019-06-17T15:10:30+0000\"\n"
				+ "        },\n" + "        {\n" + "            \"id\": 1532,\n"
				+ "            \"name\": \"Nomad Africa\",\n"
				+ "            \"description\": null,\n"
				+ "            \"remote_identifier\": null,\n"
				+ "            \"status\": 1,\n"
				+ "            \"legacy_identifier\": null,\n"
				+ "            \"created_at\": \"2019-06-17T15:07:47+0000\",\n"
				+ "            \"modified_at\": \"2019-06-17T15:07:47+0000\"\n"
				+ "        },\n" + "        {\n" + "            \"id\": 1531,\n"
				+ "            \"name\": \"Fleurieu Living Magazine\",\n"
				+ "            \"description\": null,\n"
				+ "            \"remote_identifier\": null,\n"
				+ "            \"status\": 1,\n"
				+ "            \"legacy_identifier\": null,\n"
				+ "            \"created_at\": \"2019-06-17T15:06:18+0000\",\n"
				+ "            \"modified_at\": \"2019-06-17T15:06:18+0000\"\n"
				+ "        }\n" + "    ]\n" + "}";
		ObjectMapper mapper = new ObjectMapper();
		Result result = null;
		try {

			result = mapper.readValue(jsonStr, Result.class);
		} catch (JsonMappingException e) {
		} catch (JsonProcessingException e) {
		}

		return result;
	}

}
